import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Mic, X, ArrowLeft, ArrowRight, CheckCircle, List, Briefcase } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { detectUserTimezone, getCommonTimezones } from "@/lib/timezone";
import type { OnboardingData } from "@/types";
import { WelcomeSlides } from "./welcome-slides";

// Helper function to get profession-specific lists preview
function getProfessionLists(profession: string): string[] {
  const professionLower = profession.toLowerCase();
  
  const professionListsMap: Record<string, string[]> = {
    teacher: ["School Supplies", "Teaching Tasks", "Educational Reading"],
    educator: ["Educational Supplies", "Education Tasks"],
    contractor: ["Project Punch List", "Tools & Materials", "Business Tasks"],
    builder: ["Construction Tasks", "Building Materials"],
    realtor: ["Real Estate Tasks", "Property Visits", "Client Appreciation"],
    doctor: ["Patient Care", "Medical Reading"],
    nurse: ["Nursing Tasks", "Medical Supplies"],
    developer: ["Development Tasks", "Tech Reading"],
    programmer: ["Programming Tasks", "Programming Books"],
    designer: ["Design Projects", "Design Supplies"],
    manager: ["Management Tasks", "Leadership Reading"],
    salesperson: ["Sales Activities", "Client Visits"],
    chef: ["Kitchen Supplies", "Kitchen Tasks"],
    cook: ["Cooking Supplies", "Meal Planning"]
  };
  
  // Find matching profession
  for (const [prof, lists] of Object.entries(professionListsMap)) {
    if (professionLower.includes(prof) || prof.includes(professionLower)) {
      return lists;
    }
  }
  
  // Default lists for unknown professions
  return ["Work Tasks", "Office Supplies"];
}

interface OnboardingFlowProps {
  onComplete: (data: OnboardingData) => void;
  onClose: () => void;
}

const TOTAL_STEPS = 3;

export function OnboardingFlow({ onComplete, onClose }: OnboardingFlowProps) {
  const [showWelcomeSlides, setShowWelcomeSlides] = useState(false); // Skip welcome slides
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<OnboardingData>({
    name: "",
    age: undefined,
    location: "",
    profession: "",
    religious: "",
    dietary: [],
    sleepSchedule: { bedtime: "", wakeup: "" },
    communicationStyle: "",
    interests: [],
    familyDetails: "",
    timezone: detectUserTimezone(), // Auto-detect user's timezone
  });
  
  // Show welcome slides first, then onboarding form
  if (showWelcomeSlides) {
    return <WelcomeSlides onComplete={() => setShowWelcomeSlides(false)} />;
  }

  const updateData = (updates: Partial<OnboardingData>) => {
    setData(prev => ({ ...prev, ...updates }));
  };

  const nextStep = () => {
    if (currentStep < TOTAL_STEPS) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete(data);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const progress = (currentStep / TOTAL_STEPS) * 100;

  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50 flex flex-col">
      {/* Header */}
      <div className="px-6 pt-8 pb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
            Step {currentStep} of {TOTAL_STEPS}
          </span>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {currentStep === 1 && (
          <QuickInfoStep
            data={data}
            updateData={updateData}
            onNext={nextStep}
            onClose={onClose}
          />
        )}
        
        {currentStep === 2 && (
          <PersonalizeStep
            data={data}
            updateData={updateData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        )}
        
        {currentStep === 3 && (
          <FinalQuickStep
            data={data}
            updateData={updateData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        )}
      </div>
    </div>
  );
}

// New simplified steps for ADHD users
function QuickInfoStep({ 
  data, 
  updateData, 
  onNext,
  onClose 
}: { 
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onClose: () => void;
}) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">Quick Setup 🚀</h2>
        <p className="text-gray-600">Just the essentials - 30 seconds!</p>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="name" className="text-base mb-2">What should I call you?</Label>
          <Input
            id="name"
            placeholder="Your first name"
            value={data.name}
            onChange={(e) => updateData({ name: e.target.value })}
            className="text-lg"
            autoFocus
          />
        </div>
        
        <div>
          <Label htmlFor="profession" className="text-base mb-2">What do you do?</Label>
          <Input
            id="profession"
            placeholder="e.g., Teacher, Student, Parent"
            value={data.profession}
            onChange={(e) => updateData({ profession: e.target.value })}
            className="text-lg"
          />
        </div>
      </div>
      
      <div className="flex gap-3 pt-4">
        <Button
          variant="outline"
          onClick={onClose}
          className="flex-1"
        >
          Skip for now
        </Button>
        <Button
          onClick={onNext}
          className="flex-1 bg-blue-600 hover:bg-blue-700"
        >
          Next →
        </Button>
      </div>
    </div>
  );
}

function PersonalizeStep({
  data,
  updateData,
  onNext,
  onPrev
}: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  const quickInterests = [
    "🏃 Fitness", "🎮 Gaming", "📚 Reading", 
    "🎵 Music", "🍳 Cooking", "🎨 Art",
    "🐕 Pets", "🌱 Nature", "⚽ Sports"
  ];
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Help me know you better</h2>
        <p className="text-gray-600">Pick what you like (optional)</p>
      </div>
      
      <div>
        <Label className="text-base mb-3">Your interests:</Label>
        <div className="grid grid-cols-3 gap-2">
          {quickInterests.map((interest) => {
            const isSelected = data.interests?.includes(interest) || false;
            return (
              <Button
                key={interest}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  const current = data.interests || [];
                  if (isSelected) {
                    updateData({ interests: current.filter(i => i !== interest) });
                  } else {
                    updateData({ interests: [...current, interest] });
                  }
                }}
                className="h-auto py-2"
              >
                {interest}
              </Button>
            );
          })}
        </div>
      </div>
      
      <div className="flex gap-3 pt-4">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex-1"
        >
          ← Back
        </Button>
        <Button
          onClick={onNext}
          className="flex-1 bg-blue-600 hover:bg-blue-700"
        >
          Next →
        </Button>
      </div>
    </div>
  );
}

function FinalQuickStep({
  data,
  updateData,
  onNext,
  onPrev
}: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="h-10 w-10 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">All set! 🎉</h2>
        <p className="text-gray-600">Ready to start using GabAi</p>
      </div>
      
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
        <h3 className="font-semibold mb-2">What you can do:</h3>
        <ul className="space-y-1 text-sm">
          <li>✅ Set SMS reminders</li>
          <li>✅ Create smart lists</li>
          <li>✅ Chat with your AI assistant</li>
          <li>✅ Track your tasks</li>
        </ul>
      </div>
      
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex-1"
        >
          ← Back
        </Button>
        <Button
          onClick={onNext}
          className="flex-1 bg-green-600 hover:bg-green-700"
        >
          Start Using GabAi
        </Button>
      </div>
    </div>
  );
}

function WelcomeStep({ onNext }: { onNext: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
        <Mic className="h-12 w-12 text-white" />
      </div>
      
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
        Welcome to GabAi
      </h1>
      
      <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed mb-8 max-w-md">
        Your personal voice assistant that learns about you to provide better, more personalized help.
      </p>

      <div className="space-y-4 mb-8 text-left">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
            <span className="text-green-600 dark:text-green-400 text-sm">🧠</span>
          </div>
          <span className="text-gray-700 dark:text-gray-300">Smart conversations that remember your preferences</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
            <span className="text-green-600 dark:text-green-400 text-sm">📝</span>
          </div>
          <span className="text-gray-700 dark:text-gray-300">Personalized shopping lists and reminders</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
            <span className="text-green-600 dark:text-green-400 text-sm">📅</span>
          </div>
          <span className="text-gray-700 dark:text-gray-300">Calendar integration and smart scheduling</span>
        </div>
      </div>

      <Button onClick={onNext} className="w-full max-w-sm">
        Let's Get Started
        <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  );
}

function BasicInfoStep({ data, updateData, onNext, onPrev }: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Tell me about yourself
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          This helps me personalize our conversations
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="name">What should I call you? *</Label>
          <Input
            id="name"
            value={data.name}
            onChange={(e) => updateData({ name: e.target.value })}
            placeholder="Your name"
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="age">Age (optional)</Label>
          <Input
            id="age"
            type="number"
            value={data.age || ""}
            onChange={(e) => updateData({ age: e.target.value ? parseInt(e.target.value) : undefined })}
            placeholder="25"
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={data.location}
            onChange={(e) => updateData({ location: e.target.value })}
            placeholder="City, Country"
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="profession">Profession (optional)</Label>
          <Input
            id="profession"
            value={data.profession}
            onChange={(e) => updateData({ profession: e.target.value })}
            placeholder="Software Engineer"
            className="mt-1"
          />
          {data.profession && (
            <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300 mb-2">
                <Briefcase className="h-4 w-4" />
                <span className="text-sm font-medium">Lists we'll create for you:</span>
              </div>
              <div className="text-sm text-blue-600 dark:text-blue-400">
                {getProfessionLists(data.profession).map((list, index) => (
                  <div key={index} className="flex items-center gap-1">
                    <List className="h-3 w-3" />
                    <span>{list}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex space-x-4 pt-4">
        <Button variant="outline" onClick={onPrev} className="flex-1">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button 
          onClick={onNext} 
          className="flex-1"
          disabled={!data.name.trim()}
        >
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function PreferencesStep({ data, updateData, onNext, onPrev }: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  const dietaryOptions = [
    "Vegetarian", "Vegan", "Gluten-free", "Dairy-free", "Keto", 
    "Paleo", "Halal", "Kosher", "Nut-free", "Low-sodium"
  ];

  const toggleDietary = (option: string) => {
    const current = data.dietary || [];
    const updated = current.includes(option)
      ? current.filter(item => item !== option)
      : [...current, option];
    updateData({ dietary: updated });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Dietary & Religious Preferences
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Help me suggest appropriate options for you
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="religious">Religious beliefs (optional)</Label>
          <Input
            id="religious"
            value={data.religious}
            onChange={(e) => updateData({ religious: e.target.value })}
            placeholder="e.g., Christian, Muslim, Jewish, Hindu, Buddhist, etc."
            className="mt-1"
          />
        </div>

        <div>
          <Label>Dietary restrictions (select all that apply)</Label>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {dietaryOptions.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={option}
                  checked={data.dietary?.includes(option) || false}
                  onCheckedChange={() => toggleDietary(option)}
                />
                <Label htmlFor={option} className="text-sm">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex space-x-4 pt-4">
        <Button variant="outline" onClick={onPrev} className="flex-1">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function LifestyleStep({ data, updateData, onNext, onPrev }: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  const commStyles = [
    "Casual and friendly",
    "Professional and formal", 
    "Direct and to-the-point",
    "Supportive and encouraging",
    "Humorous and lighthearted"
  ];
  
  const timezones = getCommonTimezones();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Lifestyle & Communication
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Help me adapt to your daily routine and communication style
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label>Sleep Schedule (optional)</Label>
          <div className="grid grid-cols-2 gap-4 mt-2">
            <div>
              <Label htmlFor="bedtime" className="text-sm">Bedtime</Label>
              <Input
                id="bedtime"
                type="time"
                value={data.sleepSchedule?.bedtime || ""}
                onChange={(e) => updateData({ 
                  sleepSchedule: { 
                    bedtime: e.target.value,
                    wakeup: data.sleepSchedule?.wakeup || ""
                  } 
                })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="wakeup" className="text-sm">Wake up</Label>
              <Input
                id="wakeup"
                type="time"
                value={data.sleepSchedule?.wakeup || ""}
                onChange={(e) => updateData({ 
                  sleepSchedule: { 
                    bedtime: data.sleepSchedule?.bedtime || "",
                    wakeup: e.target.value 
                  } 
                })}
                className="mt-1"
              />
            </div>
          </div>
        </div>

        <div>
          <Label>What's your timezone?</Label>
          <p className="text-sm text-gray-500 mt-1 mb-2">This helps me schedule reminders and appointments correctly.</p>
          <Select value={data.timezone || detectUserTimezone()} onValueChange={(value) => updateData({ timezone: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select your timezone" />
            </SelectTrigger>
            <SelectContent className="max-h-60">
              {getCommonTimezones().map((tz) => (
                <SelectItem key={tz.value} value={tz.value}>
                  {tz.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>How would you like me to communicate with you?</Label>
          <div className="space-y-2 mt-2">
            {commStyles.map((style) => (
              <div key={style} className="flex items-center space-x-2">
                <Checkbox
                  id={style}
                  checked={data.communicationStyle === style}
                  onCheckedChange={(checked) => 
                    checked && updateData({ communicationStyle: style })
                  }
                />
                <Label htmlFor={style} className="text-sm">
                  {style}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex space-x-4 pt-4">
        <Button variant="outline" onClick={onPrev} className="flex-1">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function InterestsStep({ data, updateData, onNext, onPrev }: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  const interestOptions = [
    "Technology", "Sports", "Cooking", "Travel", "Music", "Movies",
    "Reading", "Gaming", "Fitness", "Art", "Photography", "Gardening",
    "Fashion", "Finance", "Health", "Science", "Politics", "History"
  ];

  const toggleInterest = (interest: string) => {
    const current = data.interests || [];
    const updated = current.includes(interest)
      ? current.filter(item => item !== interest)
      : [...current, interest];
    updateData({ interests: updated });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Interests & Hobbies
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          What topics interest you most?
        </p>
      </div>

      <div>
        <Label>Select your interests (choose as many as you like)</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {interestOptions.map((interest) => (
            <div key={interest} className="flex items-center space-x-2">
              <Checkbox
                id={interest}
                checked={data.interests?.includes(interest) || false}
                onCheckedChange={() => toggleInterest(interest)}
              />
              <Label htmlFor={interest} className="text-sm">
                {interest}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="flex space-x-4 pt-4">
        <Button variant="outline" onClick={onPrev} className="flex-1">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function FinalStep({ data, updateData, onNext, onPrev }: {
  data: OnboardingData;
  updateData: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Almost done!
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Any additional details about your family or personal life?
        </p>
      </div>

      <div>
        <Label htmlFor="family">Family & Personal Details (optional)</Label>
        <Textarea
          id="family"
          value={data.familyDetails}
          onChange={(e) => updateData({ familyDetails: e.target.value })}
          placeholder="e.g., Married with 2 kids, living with parents, pet owner, etc."
          className="mt-1 min-h-[100px]"
        />
      </div>

      <Card>
        <CardContent className="pt-6">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
            Your Profile Summary
          </h3>
          <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
            <p><strong>Name:</strong> {data.name}</p>
            {data.age && <p><strong>Age:</strong> {data.age}</p>}
            {data.location && <p><strong>Location:</strong> {data.location}</p>}
            {data.profession && <p><strong>Profession:</strong> {data.profession}</p>}
            {data.religious && <p><strong>Religious:</strong> {data.religious}</p>}
            {data.dietary && data.dietary.length > 0 && (
              <p><strong>Dietary:</strong> {data.dietary.join(", ")}</p>
            )}
            {data.communicationStyle && (
              <p><strong>Communication:</strong> {data.communicationStyle}</p>
            )}
            {data.interests && data.interests.length > 0 && (
              <p><strong>Interests:</strong> {data.interests.join(", ")}</p>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex space-x-4 pt-4">
        <Button variant="outline" onClick={onPrev} className="flex-1">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Complete Setup
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
