// Complete Fix for GabAi APK Issues - Authentication & Phone Reminders
(function() {
    'use strict';
    
    // Permission state cache to prevent multiple prompts
    const permissionCache = {
        camera: null,
        microphone: null,
        lastCheck: 0
    };
    
    // Cache duration: 5 minutes
    const CACHE_DURATION = 5 * 60 * 1000;
    
    // Load cached permissions from localStorage
    function loadPermissionCache() {
        try {
            const cached = localStorage.getItem('gabai_permissions');
            if (cached) {
                const data = JSON.parse(cached);
                if (Date.now() - data.lastCheck < CACHE_DURATION) {
                    Object.assign(permissionCache, data);
                }
            }
        } catch (e) {
            console.log('[GabAiFix] No cached permissions');
        }
    }
    
    // Save permission cache
    function savePermissionCache() {
        try {
            permissionCache.lastCheck = Date.now();
            localStorage.setItem('gabai_permissions', JSON.stringify(permissionCache));
        } catch (e) {
            console.error('[GabAiFix] Failed to cache permissions');
        }
    }
    
    // Wait for device ready
    document.addEventListener('deviceready', onDeviceReady, false);
    
    function onDeviceReady() {
        console.log('[GabAiFix] Device ready, initializing complete fix with auth');
        
        // Load cached permissions
        loadPermissionCache();
        
        // ChatGPT Fix: Don't overlay status bar and set proper background
        if (window.StatusBar) {
            StatusBar.overlaysWebView(false);
            StatusBar.styleDefault();
            StatusBar.backgroundColorByHexString('#ffffff');
        }
        
        // Enhanced permission handlers with caching
        window.GabAiFixed = {
            // Check camera permission with caching
            ensureCameraPermission: function() {
                return new Promise((resolve, reject) => {
                    // Check cache first
                    if (permissionCache.camera === 'granted' && 
                        Date.now() - permissionCache.lastCheck < CACHE_DURATION) {
                        console.log('[GabAiFix] Camera permission cached as granted');
                        resolve(true);
                        return;
                    }
                    
                    if (!window.cordova?.plugins?.diagnostic) {
                        console.log('[GabAiFix] No Cordova, auto-granting');
                        permissionCache.camera = 'granted';
                        resolve(true);
                        return;
                    }
                    
                    const diagnostic = cordova.plugins.diagnostic;
                    
                    diagnostic.getCameraAuthorizationStatus(function(status) {
                        console.log('[GabAiFix] Camera status:', status);
                        
                        if (status === diagnostic.permissionStatus.GRANTED) {
                            permissionCache.camera = 'granted';
                            savePermissionCache();
                            resolve(true);
                        } else if (status === diagnostic.permissionStatus.DENIED_ALWAYS) {
                            permissionCache.camera = 'denied_always';
                            savePermissionCache();
                            alert('Camera permission is required. Please enable it in Settings > Apps > GabAi > Permissions');
                            if (diagnostic.switchToSettings) {
                                diagnostic.switchToSettings();
                            }
                            reject(new Error('Camera permission permanently denied'));
                        } else {
                            // Request permission only if not cached
                            diagnostic.requestCameraAuthorization(function(newStatus) {
                                if (newStatus === diagnostic.permissionStatus.GRANTED) {
                                    permissionCache.camera = 'granted';
                                    savePermissionCache();
                                    resolve(true);
                                } else {
                                    permissionCache.camera = 'denied';
                                    savePermissionCache();
                                    reject(new Error('Camera permission denied'));
                                }
                            }, reject);
                        }
                    }, reject);
                });
            },
            
            // Check microphone permission with caching
            ensureMicrophonePermission: function() {
                return new Promise((resolve, reject) => {
                    // Check cache first
                    if (permissionCache.microphone === 'granted' && 
                        Date.now() - permissionCache.lastCheck < CACHE_DURATION) {
                        console.log('[GabAiFix] Microphone permission cached as granted');
                        resolve(true);
                        return;
                    }
                    
                    if (!window.cordova?.plugins?.diagnostic) {
                        console.log('[GabAiFix] No Cordova, auto-granting');
                        permissionCache.microphone = 'granted';
                        resolve(true);
                        return;
                    }
                    
                    const diagnostic = cordova.plugins.diagnostic;
                    
                    diagnostic.getMicrophoneAuthorizationStatus(function(status) {
                        console.log('[GabAiFix] Microphone status:', status);
                        
                        if (status === diagnostic.permissionStatus.GRANTED) {
                            permissionCache.microphone = 'granted';
                            savePermissionCache();
                            resolve(true);
                        } else if (status === diagnostic.permissionStatus.DENIED_ALWAYS) {
                            permissionCache.microphone = 'denied_always';
                            savePermissionCache();
                            alert('Microphone permission is required for voice input. Please enable it in Settings > Apps > GabAi > Permissions');
                            if (diagnostic.switchToSettings) {
                                diagnostic.switchToSettings();
                            }
                            reject(new Error('Microphone permission permanently denied'));
                        } else {
                            diagnostic.requestMicrophoneAuthorization(function(newStatus) {
                                if (newStatus === diagnostic.permissionStatus.GRANTED) {
                                    permissionCache.microphone = 'granted';
                                    savePermissionCache();
                                    resolve(true);
                                } else {
                                    permissionCache.microphone = 'denied';
                                    savePermissionCache();
                                    reject(new Error('Microphone permission denied'));
                                }
                            }, reject);
                        }
                    }, reject);
                });
            },
            
            // Take photo and return as Blob for OCR
            capturePhotoAsBlob: function() {
                const self = this;
                
                return new Promise((resolve, reject) => {
                    // Ensure camera permission first
                    self.ensureCameraPermission().then(() => {
                        if (!navigator.camera) {
                            reject(new Error('Camera not available'));
                            return;
                        }
                        
                        const options = {
                            quality: 90,
                            destinationType: Camera.DestinationType.DATA_URL,
                            sourceType: Camera.PictureSourceType.CAMERA,
                            allowEdit: false,
                            encodingType: Camera.EncodingType.JPEG,
                            targetWidth: 1920,
                            targetHeight: 1920,
                            correctOrientation: true,
                            saveToPhotoAlbum: false
                        };
                        
                        navigator.camera.getPicture(
                            function(imageData) {
                                console.log('[GabAiFix] Photo captured, converting to Blob');
                                
                                // Convert base64 to Blob
                                const dataUrl = 'data:image/jpeg;base64,' + imageData;
                                
                                // Convert data URL to Blob
                                fetch(dataUrl)
                                    .then(res => res.blob())
                                    .then(blob => {
                                        console.log('[GabAiFix] Blob created, size:', blob.size);
                                        // Create a File object for better compatibility
                                        const file = new File([blob], 'camera-photo.jpg', { 
                                            type: 'image/jpeg',
                                            lastModified: Date.now()
                                        });
                                        resolve(file);
                                    })
                                    .catch(err => {
                                        console.error('[GabAiFix] Blob conversion failed:', err);
                                        reject(err);
                                    });
                            },
                            function(error) {
                                console.error('[GabAiFix] Camera error:', error);
                                reject(new Error('Camera capture failed: ' + error));
                            },
                            options
                        );
                    }).catch(reject);
                });
            },
            
            // Upload image to OCR
            uploadToOCR: function(file) {
                return new Promise((resolve, reject) => {
                    console.log('[GabAiFix] Uploading to OCR, file size:', file.size);
                    
                    const formData = new FormData();
                    // Try both field names for compatibility
                    formData.append('image', file, file.name || 'photo.jpg');
                    formData.append('file', file, file.name || 'photo.jpg');
                    
                    // Get auth token if available
                    const token = localStorage.getItem('gabai_token') ||
                                 localStorage.getItem('token');
                    const headers = {};
                    if (token) {
                        headers['Authorization'] = `Bearer ${token}`;
                        console.log('[GabAiFix] Adding Bearer token to OCR request');
                    }
                    
                    fetch('https://gabai.ai/api/ocr', {
                        method: 'POST',
                        body: formData,
                        headers: headers,
                        credentials: 'omit' // Don't send cookies from file://
                    })
                    .then(response => {
                        console.log('[GabAiFix] OCR response status:', response.status);
                        if (!response.ok) {
                            throw new Error('OCR failed with status: ' + response.status);
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('[GabAiFix] OCR success, text length:', data.text?.length);
                        resolve(data);
                    })
                    .catch(error => {
                        console.error('[GabAiFix] OCR upload error:', error);
                        reject(error);
                    });
                });
            },
            
            // Complete camera to OCR flow
            captureAndOCR: function() {
                const self = this;
                
                return self.capturePhotoAsBlob()
                    .then(file => self.uploadToOCR(file))
                    .then(result => {
                        console.log('[GabAiFix] OCR complete');
                        return result;
                    })
                    .catch(error => {
                        console.error('[GabAiFix] Camera to OCR failed:', error);
                        throw error;
                    });
            }
        };
        
        // Override camera capture buttons to use our fixed flow
        document.addEventListener('click', function(e) {
            const target = e.target;
            
            // Check if this is a camera button for OCR
            if (target.closest('[data-testid*="camera"]') || 
                target.closest('.camera-button') ||
                (target.tagName === 'BUTTON' && target.textContent.includes('Camera'))) {
                
                // Check if we're in the OCR page
                if (window.location.hash.includes('ocr') || 
                    window.location.pathname.includes('ocr')) {
                    
                    console.log('[GabAiFix] Intercepting camera button for OCR');
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Use our fixed camera to OCR flow
                    window.GabAiFixed.captureAndOCR()
                        .then(result => {
                            // Dispatch custom event with OCR result
                            const event = new CustomEvent('ocr-complete', {
                                detail: { text: result.text }
                            });
                            document.dispatchEvent(event);
                            
                            // Try to update the UI directly
                            const textarea = document.querySelector('textarea');
                            if (textarea) {
                                textarea.value = result.text;
                                textarea.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        })
                        .catch(error => {
                            alert('Failed to extract text from image. Please try again.');
                        });
                }
            }
        }, true);
        
        // Enhanced authentication fix
        window.GabAiAuth = {
            // Ensure token is available for API calls
            ensureToken: function() {
                const token = localStorage.getItem('gabai_token') ||
                             localStorage.getItem('token') ||
                             sessionStorage.getItem('gabai_token') ||
                             sessionStorage.getItem('token');
                
                if (token) {
                    console.log('[GabAiFix] Token available for auth');
                    // Store in multiple places for compatibility
                    if (!localStorage.getItem('gabai_token')) {
                        localStorage.setItem('gabai_token', token);
                    }
                    if (!localStorage.getItem('token')) {
                        localStorage.setItem('token', token);
                    }
                }
                return token;
            },
            
            // Check SMS consent status
            checkSMSConsent: function() {
                const user = JSON.parse(localStorage.getItem('user') || '{}');
                const hasConsent = user.preferences?.smsConsent === true && user.phone;
                console.log('[GabAiFix] SMS Consent status:', hasConsent, 'Phone:', user.phone);
                return hasConsent;
            }
        };
        
        // Check token on load
        window.GabAiAuth.ensureToken();
        
        console.log('[GabAiFix] Complete fix with auth initialized');
        console.table({
            cordova: !!window.cordova,
            camera: !!navigator.camera,
            diagnostic: !!window.cordova?.plugins?.diagnostic,
            statusBar: !!window.StatusBar,
            cachedPermissions: permissionCache,
            hasToken: !!window.GabAiAuth.ensureToken()
        });
    }
})();