// Runtime Permission Handler for GabAi
(function() {
    'use strict';
    
    // Wait for device ready
    document.addEventListener('deviceready', onDeviceReady, false);
    
    function onDeviceReady() {
        console.log('[Permissions] Device ready, initializing permission handler');
        
        // Store original functions
        window.GabAiPermissions = {
            // Request camera permission
            requestCamera: function() {
                return new Promise((resolve, reject) => {
                    if (!window.cordova || !window.cordova.plugins || !window.cordova.plugins.diagnostic) {
                        console.log('[Permissions] Running in browser, auto-granting camera');
                        resolve(true);
                        return;
                    }
                    
                    cordova.plugins.diagnostic.getCameraAuthorizationStatus(function(status) {
                        console.log('[Permissions] Camera status:', status);
                        
                        if (status === cordova.plugins.diagnostic.permissionStatus.GRANTED) {
                            console.log('[Permissions] Camera already authorized');
                            resolve(true);
                        } else if (status === cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS) {
                            console.log('[Permissions] Camera permanently denied');
                            alert('Camera permission is required. Please enable it in Settings > Apps > GabAi > Permissions');
                            reject(new Error('Camera permission permanently denied'));
                        } else {
                            // Request permission
                            console.log('[Permissions] Requesting camera permission...');
                            cordova.plugins.diagnostic.requestCameraAuthorization(function(newStatus) {
                                console.log('[Permissions] Camera request result:', newStatus);
                                if (newStatus === cordova.plugins.diagnostic.permissionStatus.GRANTED) {
                                    resolve(true);
                                } else {
                                    reject(new Error('Camera permission denied'));
                                }
                            }, function(error) {
                                console.error('[Permissions] Camera request error:', error);
                                reject(error);
                            });
                        }
                    }, function(error) {
                        console.error('[Permissions] Camera check error:', error);
                        reject(error);
                    });
                });
            },
            
            // Request microphone permission
            requestMicrophone: function() {
                return new Promise((resolve, reject) => {
                    if (!window.cordova || !window.cordova.plugins || !window.cordova.plugins.diagnostic) {
                        console.log('[Permissions] Running in browser, auto-granting microphone');
                        resolve(true);
                        return;
                    }
                    
                    cordova.plugins.diagnostic.getMicrophoneAuthorizationStatus(function(status) {
                        console.log('[Permissions] Microphone status:', status);
                        
                        if (status === cordova.plugins.diagnostic.permissionStatus.GRANTED) {
                            console.log('[Permissions] Microphone already authorized');
                            resolve(true);
                        } else if (status === cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS) {
                            console.log('[Permissions] Microphone permanently denied');
                            alert('Microphone permission is required for voice input. Please enable it in Settings > Apps > GabAi > Permissions');
                            reject(new Error('Microphone permission permanently denied'));
                        } else {
                            // Request permission
                            console.log('[Permissions] Requesting microphone permission...');
                            cordova.plugins.diagnostic.requestMicrophoneAuthorization(function(newStatus) {
                                console.log('[Permissions] Microphone request result:', newStatus);
                                if (newStatus === cordova.plugins.diagnostic.permissionStatus.GRANTED) {
                                    resolve(true);
                                } else {
                                    reject(new Error('Microphone permission denied'));
                                }
                            }, function(error) {
                                console.error('[Permissions] Microphone request error:', error);
                                reject(error);
                            });
                        }
                    }, function(error) {
                        console.error('[Permissions] Microphone check error:', error);
                        reject(error);
                    });
                });
            },
            
            // Request both permissions
            requestAll: function() {
                return Promise.all([
                    this.requestCamera().catch(err => console.warn('Camera permission failed:', err)),
                    this.requestMicrophone().catch(err => console.warn('Microphone permission failed:', err))
                ]);
            }
        };
        
        // Override navigator.mediaDevices.getUserMedia to include permission check
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
            
            navigator.mediaDevices.getUserMedia = function(constraints) {
                console.log('[Permissions] getUserMedia called with constraints:', constraints);
                
                // Check what permissions are needed
                const promises = [];
                
                if (constraints.video) {
                    promises.push(window.GabAiPermissions.requestCamera());
                }
                
                if (constraints.audio) {
                    promises.push(window.GabAiPermissions.requestMicrophone());
                }
                
                if (promises.length > 0) {
                    return Promise.all(promises).then(() => {
                        console.log('[Permissions] All required permissions granted, calling original getUserMedia');
                        return originalGetUserMedia(constraints);
                    }).catch(err => {
                        console.error('[Permissions] Permission request failed:', err);
                        throw err;
                    });
                } else {
                    return originalGetUserMedia(constraints);
                }
            };
        }
        
        // Override Cordova camera plugin if present
        if (window.navigator.camera && window.navigator.camera.getPicture) {
            const originalGetPicture = window.navigator.camera.getPicture.bind(window.navigator.camera);
            
            window.navigator.camera.getPicture = function(onSuccess, onFail, options) {
                console.log('[Permissions] Camera.getPicture called');
                
                window.GabAiPermissions.requestCamera().then(() => {
                    console.log('[Permissions] Camera permission granted, taking picture');
                    originalGetPicture(onSuccess, onFail, options);
                }).catch(err => {
                    console.error('[Permissions] Camera permission failed:', err);
                    if (onFail) onFail(err.message);
                });
            };
        }
        
        // Auto-request permissions on first app launch
        setTimeout(() => {
            console.log('[Permissions] Checking initial permissions...');
            // Don't auto-request, let the app request when needed
        }, 1000);
    }
})();