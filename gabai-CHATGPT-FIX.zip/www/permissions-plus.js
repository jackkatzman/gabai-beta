// Enhanced Permission Handler with Auth & Retry Logic for GabAi
(function() {
    'use strict';
    
    // Wait for device ready
    document.addEventListener('deviceready', onDeviceReady, false);
    
    // Auth token management
    window.GabAiAuth = {
        setToken: function(token) {
            localStorage.setItem('auth_token', token);
        },
        getToken: function() {
            return localStorage.getItem('auth_token');
        }
    };
    
    // Enhanced API helper with Bearer token
    window.GabAiAPI = function(path, init = {}) {
        const headers = new Headers(init.headers || {});
        const token = window.GabAiAuth.getToken();
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        headers.set('X-Requested-With', 'XMLHttpRequest');
        
        // For APK, use full URL
        const url = path.startsWith('http') ? path : `https://gabai.ai${path}`;
        
        return fetch(url, {
            ...init,
            headers: headers,
            credentials: 'include' // Keep cookies as backup
        }).then(res => {
            if (res.status === 401) {
                throw new Error('Not authenticated');
            }
            return res;
        });
    };
    
    // MediaRecorder management
    let mediaRecorder = null;
    let mediaStream = null;
    let recordingTimeout = null;
    
    function onDeviceReady() {
        console.log('[Permissions+] Device ready, initializing enhanced handler');
        
        // Status bar fix for UI cutoff
        if (window.StatusBar) {
            StatusBar.overlaysWebView(false);
            StatusBar.styleDefault();
        }
        
        window.GabAiPermissions = {
            // Enhanced microphone permission with retry
            ensureMicrophonePermission: function() {
                return new Promise((resolve, reject) => {
                    if (!window.cordova || !window.cordova.plugins || !window.cordova.plugins.diagnostic) {
                        console.log('[Permissions+] No Cordova, auto-granting');
                        resolve(true);
                        return;
                    }
                    
                    const diagnostic = cordova.plugins.diagnostic;
                    
                    diagnostic.getMicrophoneAuthorizationStatus(function(status) {
                        console.log('[Permissions+] Mic status:', status);
                        
                        if (status === diagnostic.permissionStatus.GRANTED) {
                            resolve(true);
                        } else if (status === diagnostic.permissionStatus.DENIED_ALWAYS) {
                            // Open settings for permanently denied
                            if (diagnostic.switchToSettings) {
                                diagnostic.switchToSettings();
                            }
                            reject(new Error('Microphone permission permanently denied'));
                        } else {
                            // Request permission
                            diagnostic.requestMicrophoneAuthorization(function(newStatus) {
                                if (newStatus === diagnostic.permissionStatus.GRANTED) {
                                    resolve(true);
                                } else {
                                    reject(new Error('Microphone permission denied'));
                                }
                            }, reject);
                        }
                    }, reject);
                });
            },
            
            // Enhanced camera permission
            ensureCameraPermission: function() {
                return new Promise((resolve, reject) => {
                    if (!window.cordova || !window.cordova.plugins || !window.cordova.plugins.diagnostic) {
                        console.log('[Permissions+] No Cordova, auto-granting');
                        resolve(true);
                        return;
                    }
                    
                    const diagnostic = cordova.plugins.diagnostic;
                    
                    diagnostic.getCameraAuthorizationStatus(function(status) {
                        console.log('[Permissions+] Camera status:', status);
                        
                        if (status === diagnostic.permissionStatus.GRANTED) {
                            resolve(true);
                        } else if (status === diagnostic.permissionStatus.DENIED_ALWAYS) {
                            if (diagnostic.switchToSettings) {
                                diagnostic.switchToSettings();
                            }
                            reject(new Error('Camera permission permanently denied'));
                        } else {
                            diagnostic.requestCameraAuthorization(function(newStatus) {
                                if (newStatus === diagnostic.permissionStatus.GRANTED) {
                                    resolve(true);
                                } else {
                                    reject(new Error('Camera permission denied'));
                                }
                            }, reject);
                        }
                    }, reject);
                });
            },
            
            // Stop and cleanup media recording
            stopRecording: function() {
                console.log('[Permissions+] Stopping recording and cleanup');
                
                // Clear timeout
                if (recordingTimeout) {
                    clearTimeout(recordingTimeout);
                    recordingTimeout = null;
                }
                
                // Stop recorder
                try {
                    if (mediaRecorder && mediaRecorder.state === 'recording') {
                        mediaRecorder.stop();
                    }
                } catch (e) {
                    console.error('[Permissions+] Error stopping recorder:', e);
                }
                
                // Stop all tracks
                if (mediaStream) {
                    try {
                        mediaStream.getTracks().forEach(track => track.stop());
                    } catch (e) {
                        console.error('[Permissions+] Error stopping tracks:', e);
                    }
                }
                
                mediaRecorder = null;
                mediaStream = null;
            },
            
            // Start recording with retry logic
            startRecording: function() {
                const self = this;
                
                return new Promise(async (resolve, reject) => {
                    // Ensure permission first
                    try {
                        await self.ensureMicrophonePermission();
                    } catch (err) {
                        reject(err);
                        return;
                    }
                    
                    // Cleanup before starting
                    self.stopRecording();
                    
                    // Try recording with retry on NotReadableError
                    let lastError = null;
                    for (let attempt = 0; attempt < 2; attempt++) {
                        if (attempt > 0) {
                            console.log('[Permissions+] Retrying after NotReadableError...');
                            await new Promise(r => setTimeout(r, 500)); // Small delay
                        }
                        
                        try {
                            // Get media stream
                            mediaStream = await navigator.mediaDevices.getUserMedia({ 
                                audio: {
                                    echoCancellation: true,
                                    noiseSuppression: true,
                                    autoGainControl: true
                                } 
                            });
                            
                            // Determine MIME type
                            const mimeType = MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
                                ? 'audio/webm;codecs=opus' 
                                : 'audio/webm';
                            
                            // Create recorder
                            mediaRecorder = new MediaRecorder(mediaStream, { mimeType });
                            
                            const chunks = [];
                            
                            mediaRecorder.ondataavailable = (e) => {
                                if (e.data && e.data.size > 0) {
                                    chunks.push(e.data);
                                }
                            };
                            
                            mediaRecorder.onstop = () => {
                                const blob = new Blob(chunks, { type: mimeType });
                                resolve(blob);
                            };
                            
                            mediaRecorder.onerror = (e) => {
                                console.error('[Permissions+] Recorder error:', e);
                                self.stopRecording();
                                reject(e.error || e);
                            };
                            
                            // Start recording
                            mediaRecorder.start();
                            
                            // 60 second safety timeout
                            recordingTimeout = setTimeout(() => {
                                console.log('[Permissions+] 60s timeout, stopping recording');
                                if (mediaRecorder && mediaRecorder.state === 'recording') {
                                    mediaRecorder.stop();
                                }
                            }, 60000);
                            
                            // Success - exit retry loop
                            return;
                            
                        } catch (err) {
                            console.error('[Permissions+] Recording attempt failed:', err);
                            lastError = err;
                            self.stopRecording();
                            
                            // Only retry on NotReadableError
                            if (!String(err.name || err.message).includes('NotReadable')) {
                                reject(err);
                                return;
                            }
                        }
                    }
                    
                    // All attempts failed
                    reject(lastError || new Error('Failed to start recording'));
                });
            }
        };
        
        // File URI to Blob converter for camera
        window.GabAiFileUtils = {
            fileUriToBlob: function(fileUri) {
                return new Promise((resolve, reject) => {
                    window.resolveLocalFileSystemURL(fileUri, function(fileEntry) {
                        fileEntry.file(function(file) {
                            const reader = new FileReader();
                            reader.onloadend = function() {
                                const blob = new Blob([reader.result], { type: 'image/jpeg' });
                                resolve(blob);
                            };
                            reader.onerror = reject;
                            reader.readAsArrayBuffer(file);
                        }, reject);
                    }, reject);
                });
            },
            
            // Convert data URL to Blob
            dataUrlToBlob: function(dataUrl) {
                const arr = dataUrl.split(',');
                const mime = arr[0].match(/:(.*?);/)[1];
                const bstr = atob(arr[1]);
                let n = bstr.length;
                const u8arr = new Uint8Array(n);
                while (n--) {
                    u8arr[n] = bstr.charCodeAt(n);
                }
                return new Blob([u8arr], { type: mime });
            }
        };
        
        // Override getUserMedia with permission check and retry
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
            
            navigator.mediaDevices.getUserMedia = function(constraints) {
                console.log('[Permissions+] getUserMedia intercepted');
                
                if (constraints.audio && !constraints.video) {
                    // Use our enhanced recording with retry
                    return window.GabAiPermissions.ensureMicrophonePermission()
                        .then(() => originalGetUserMedia(constraints));
                } else if (constraints.video) {
                    return window.GabAiPermissions.ensureCameraPermission()
                        .then(() => originalGetUserMedia(constraints));
                } else {
                    return originalGetUserMedia(constraints);
                }
            };
        }
        
        // Override camera.getPicture with permission check
        if (window.navigator.camera && window.navigator.camera.getPicture) {
            const originalGetPicture = window.navigator.camera.getPicture.bind(window.navigator.camera);
            
            window.navigator.camera.getPicture = function(onSuccess, onFail, options) {
                console.log('[Permissions+] camera.getPicture intercepted');
                
                window.GabAiPermissions.ensureCameraPermission().then(() => {
                    // Wrap success to convert to Blob if needed
                    const wrappedSuccess = function(result) {
                        if (options && options.destinationType === Camera.DestinationType.FILE_URI) {
                            // Convert to Blob for easier upload
                            window.GabAiFileUtils.fileUriToBlob(result)
                                .then(blob => {
                                    onSuccess({ uri: result, blob: blob });
                                })
                                .catch(err => {
                                    console.error('[Permissions+] Blob conversion failed:', err);
                                    onSuccess(result); // Fallback to original
                                });
                        } else {
                            onSuccess(result);
                        }
                    };
                    
                    originalGetPicture(wrappedSuccess, onFail, options);
                }).catch(err => {
                    console.error('[Permissions+] Camera permission failed:', err);
                    if (onFail) onFail(err.message);
                });
            };
        }
        
        console.log('[Permissions+] Enhanced handler ready');
        console.table({
            cordova: !!window.cordova,
            diagnostic: !!window.cordova?.plugins?.diagnostic,
            statusBar: !!window.StatusBar,
            camera: !!window.navigator?.camera,
            mediaDevices: !!navigator.mediaDevices
        });
    }
})();